A package with an OBJ, its MTL and a texture.
